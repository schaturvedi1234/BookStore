# BookStore
Online book store system

Installation Process : Import the Jar file to execute the functionality of book store

Get_Request - use the command given to retreive the response:
curl -i -H 'Accept: application/json' localhost:8080/books

Post_Request - use the command given to retreive the response:
curl -i -H 'Accept: application/json' localhost:8080/books/Id

Put_Request - use the command given to retreive the response:
curl -i -H 'Accept: application/json' localhost:8080/books/Id

Delete_Request - use the command given to retreive the response:
curl -i -H 'Accept: application/json' localhost:8080/books/Id

findById - use the command given to retreive the response by Id:
curl -i -H 'Accept: application/json' localhost:8080/books/findById/{Id}


